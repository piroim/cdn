#!/bin/bash
apache2-foreground &  # Apache 서버 백그라운드 실행
