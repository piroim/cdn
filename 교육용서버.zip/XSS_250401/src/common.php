<?php

    session_set_cookie_params([
        'lifetime' => 0, // 브라우저 종료 시 쿠키 만료
        'path' => '/', // 쿠키 경로
        'domain' => '', // 도메인 설정 (기본값 사용)
        'secure' => false, // HTTPS를 통해서만 쿠키 전송 (true로 설정 권장)
        'httponly' => false, // HttpOnly 속성 해제
        'samesite' => 'Lax' // SameSite 속성 설정 (선택 사항)
    ]);
    
    session_start();
    define('PUBLIC_PHP_PATH', './public/php/');
    include 'db.php';
    $flag = file_get_contents('/flag');
    
    // function xss_filter($keyword) {
    //     $keyword = preg_replace('/on/', '_', $keyword);
    //     return $keyword;
    // }
?>