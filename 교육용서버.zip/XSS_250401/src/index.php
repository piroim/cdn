<?php
    include 'common.php';
    include PUBLIC_PHP_PATH.'header.php';
?>
<html>
    <body>
        <br>
        <h2>Penetration Testing</h2>
        <p>실습페이지 입니다.</p>
        <a href="board.php" id="main">실습페이지 이동</a>
        <div id="test"></div>

    <script>
        //Dom Example 1
        var message = new URLSearchParams(window.location.search).get('message');
        document.getElementById('test').innerHTML = message;
        
        //Dom Example 2
        if (!window.location.hash.includes("#main")) {
            window.location.hash = "#main";
        }

        let hash = window.location.hash.slice(1);
        
        if(hash){
            let decodedHash = decodeURIComponent(hash);
            document.getElementById('main').innerHTML = decodedHash;
            window.location.hash = decodedHash;
        }
        window.addEventListener('hashchange', function() {
            let newHash = window.location.hash.slice(1);
            document.getElementById('main').innerHTML = decodeURIComponent(newHash);
        });
        
    </script>
    </body>
</html>

<?php include_once PUBLIC_PHP_PATH.'footer.php'; ?> 