<?php
include 'common.php';  // 데이터베이스 연결 설정 포함

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 모든 게시글 삭제 쿼리
    $sql = "DELETE FROM board";
    if ($db_conn->query($sql) === TRUE) {
        echo "<script>alert('모든 게시글이 성공적으로 삭제되었습니다.');</script>";
        echo "<script>window.location.href = 'index.php';</script>";
    } else {
        echo "Error: " . $db_conn->error;
    }

    // 데이터베이스 연결 종료
    $db_conn->close();
}
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>게시글 삭제</title>
</head>
<body>
    <h2>모든 게시글 삭제</h2>
    <form method="POST" action="delete_all_posts.php">
        <p>정말로 모든 게시글을 삭제하시겠습니까? 이 작업은 되돌릴 수 없습니다.</p>
        <button type="submit">모든 게시글 삭제</button>
    </form>
</body>
</html>
