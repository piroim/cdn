<?php
    include 'common.php';
    include 'login_process.php';
    include_once PUBLIC_PHP_PATH.'header.php';

    if (isset($_SESSION['start_time'])) {
        $elapsed_time = time() - $_SESSION['start_time'];
        $remaining_time = $_SESSION['expire_time'] - $elapsed_time;
    
        if ($remaining_time > 0) {
            echo "<div id='session_timer'>남은 세션 시간: <span id='timer'>" . $remaining_time . "</span></div>";
            echo "<script>var remainingTime = $remaining_time;</script>";
        } else {
            echo "<script>alert('로그아웃 되었습니다.')</script>";
            session_destroy();
        }
    } else {
        echo "<div class='alert'>로그인되지 않음</div>";
    }
?>

<main>
    <section>
        <h1>사용자 페이지</h1>
        <p>안녕하세요, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong>님!</p>
    </section>
    
    <section>
        <h2>세션 정보</h2>
        <ul>
            <?php foreach ($_SESSION as $key => $value): ?>
                <li><strong><?php echo htmlspecialchars($key); ?>:</strong> <?php echo htmlspecialchars($value); ?></li>
            <?php endforeach; ?>
            <li><strong>PHPSESSID:</strong> <?php echo session_id(); ?></li> <!-- PHPSESSID 출력 -->
        </ul>
    </section>

    <section>
        <form action="logout.php" method="post">
            <button type="submit" class="logout-button">로그아웃</button>
        </form>
    </section>
</main>

<?php include_once PUBLIC_PHP_PATH.'footer.php'; ?>

<script>
    function updateTimer() {
        if (remainingTime > 0) {
            remainingTime--;
            var minutes = Math.floor(remainingTime / 60);
            var seconds = remainingTime % 60;
            document.getElementById('timer').textContent = minutes + "분 " + seconds + "초";
        } else {
            clearInterval(timerInterval);
            document.getElementById('session_timer').textContent = "세션 만료";
            // 필요한 경우 추가 액션 수행
        }
    }

    // 1초마다 타이머 업데이트
    var timerInterval = setInterval(updateTimer, 1000);
    var sessionId = "<?php echo session_id(); ?>";
</script>

<style>
    main {
        padding: 20px;
        background-color: #f9f9f9;
        border-radius: 8px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }

    .logout-button {
        background-color: #333;
        color: #fff;
        padding: 10px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 10px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        transition: background-color 0.3s ease;
    }

    .logout-button:hover {
        background-color: #555;
    }

    #session_timer {
        font-size: 16px;
        margin-bottom: 20px;
        padding: 10px;
        background-color: #eee;
        border-radius: 5px;
        text-align: center;
    }

    .alert {
        color: #e74c3c;
        font-size: 18px;
        margin-bottom: 20px;
    }
</style>
