<?php
    include 'common.php';
    include PUBLIC_PHP_PATH.'filter.php';

    if($_SERVER["REQUEST_METHOD"] == "POST") {
        if(!isset($_SESSION['username'])) {
            echo "<script>alert('로그인 후, 오세용');</script>";
            echo "<script>window.location.href='login.php';</script>";
            exit();
        }

        $subject = htmlspecialchars($_POST['subject']);
        $writer = $_SESSION['username'];
        $content = $_POST['content'];

        $result = $db_conn->prepare("INSERT INTO board4(subject, writer, content) VALUES (?,?,?)");
        $result->bind_param("sss",$subject, $writer, $content);

        if($result->execute()) {
            echo "<script>alert('게시글 작성 완료!');</script>";
            echo "<script>window.location.href = 'board4.php';</script>";
        } 
        
        else {
            echo "<script>alert('게시글 작성에 실패!');</script>";
            echo "<script>window.location.href = 'board4.php';</script>";
        }
        $db_conn->close();
    }
?>