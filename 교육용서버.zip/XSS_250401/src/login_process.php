<?php
include 'common.php';

if (!session_id()) {
    session_set_cookie_params([
        'lifetime' => 0, // 브라우저 종료 시 쿠키 만료
        'path' => '/', // 쿠키 경로
        'domain' => '', // 도메인 설정 (기본값 사용)
        'secure' => false, // HTTPS를 통해서만 쿠키 전송 (true로 설정 권장)
        'httponly' => false, // HttpOnly 속성 해제
        'samesite' => 'Lax' // SameSite 속성 설정 (선택 사항)
    ]);
    session_start();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['username'];
    $pw = $_POST['password'];

    // 사용자 이름과 비밀번호로 데이터베이스에서 사용자 정보 검색
    $sql = $db_conn->prepare("SELECT * FROM security_user WHERE name=? AND password=?");
    $sql->bind_param("ss", $id, $pw);
    $sql->execute();
    $result = $sql->get_result();

    // 사용자가 존재하는지 확인
    if ($result->num_rows > 0) {
        $_SESSION['username'] = $id;
        $_SESSION['start_time'] = time();
        $_SESSION['expire_time'] = 60 * 60;
        echo "<script>alert('로그인 성공')</script>";
        echo "<script>window.location.href = 'index.php';</script>";
        exit();
    } else {
        echo "<script>alert('로그인 실패');</script>";
        echo "<script>window.location.href = 'login.php';</script>";
        exit();
    }

    $sql->close();
}
?>
