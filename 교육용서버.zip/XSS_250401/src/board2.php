<?php

    include 'common.php';
    include_once PUBLIC_PHP_PATH.'header.php';
    header("Access-Control-Allow-Origin: *");

    if (!isset($_SESSION['username'])) {
        echo "<script>
            alert('로그인이 필요합니다.');
            window.location.href = '/login.php';
        </script>";
        exit();
    }

    $username = $_SESSION['username'];
    $current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $per_page = 10;
    $offset = ($current_page - 1) * $per_page;
    
    // 관리자 계정 확인
    if ($username === 'admin') {
        // 관리자는 모든 게시글을 조회할 수 있습니다.
        $sql_query = "SELECT * FROM board2 WHERE 1=1";
        $count_query = "SELECT COUNT(*) AS total FROM board2 WHERE 1=1";
        $params = [];
        $count_params = [];
    } else {
        // 일반 사용자는 자신의 게시글만 조회
        $sql_query = "SELECT * FROM board2 WHERE writer = ?";
        $count_query = "SELECT COUNT(*) AS total FROM board2 WHERE writer = ?";
        $params = [$username];
        $count_params = [$username];
    }

    //모든 게시글 조회

    if(isset($_GET['keyword'])) {
        // $keyword = "%" . filter($_GET['keyword']) . "%";
        $keyword = $_GET['keyword'];
        $sql_query .= " AND subject LIKE ?";
        $params[] = $keyword;
    }

    // $sql_query .= " ORDER BY date DESC LIMIT ? OFFSET ?";
    $sql_query .= " ORDER BY no DESC LIMIT ? OFFSET ?";
    $params[] = $per_page;
    $params[] = $offset;

    $stmt = $db_conn->prepare($sql_query);
    $stmt->bind_param(str_repeat('s', count($params) - 2) . 'ii', ...$params);
    $stmt->execute();
    $result = $stmt->get_result();

    // 전체 게시물 수를 얻기 위한 쿼리 (검색어가 포함된 경우)
    $count_query = "SELECT COUNT(*) AS total FROM board2 WHERE writer = ?";
    $count_params = [$username];

    if (isset($_GET['keyword'])) {
        $count_query .= " AND subject LIKE ?";
        $count_params[] = $keyword;
    }

    $count_stmt = $db_conn->prepare($count_query);
    $count_stmt->bind_param(str_repeat('s', count($count_params)), ...$count_params);
    $count_stmt->execute();
    $count_result = $count_stmt->get_result();
    $row = $count_result->fetch_assoc();
    $total_rows = $row['total'];
    $total_pages = ceil($total_rows / $per_page);
?>

<main>
    <div class="search-container">
        <h2>[Stored XSS 실습] 게시판 생성/조회</h2>
        <button type="button" class="button1"><a href='board_write2.php'>게시글 작성</a></button><br>
        <form action="board2.php" method="get">
            <input type="text" class="search-box" name="keyword" placeholder="검색어를 입력하세요." value="<?php echo $keyword;?>"/>
            <button class="button" type="submit">검색</button>
            <button class="button" type="button" onclick="location.href='board2.php'">초기화</button>
        </form>
    </div>
    <table>
        <thead>
            <tr>
                <th>번호</th>
                <th class="subject">제목</th>
                <th class="writer">작성자</th>
                <th>작성일</th>
            </tr>
        </thead>
        <tbody>
            <?php
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>".$row["no"]."</td>";
                        echo "<td class='subject2'><a href='board_detail2.php?no=".$row["no"]."'>".htmlspecialchars($row["subject"], ENT_QUOTES, 'UTF-8')."</a></td>";
                        echo "<td>".$row["writer"]."</td>";
                        echo "<td>".$row["date"]."</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>게시글이 없습니다.</td></tr>";
                }
            ?>
        </tbody>
    </table>
    <div class="pagination">
        <?php
            if ($total_rows > 0) {
                for ($i = 1; $i <= $total_pages; $i++) {
                    echo "<a href='board2.php?page=$i".(isset($_GET['keyword']) ? "&keyword=".urlencode($_GET['keyword']) : "")."'". ($i == $current_page ? " class='current-page'" : "") .">$i</a> ";
                }
            }
        ?>
    </div>

    <p id="testinput"></p>
    <script>
        const queryString = document.location.search;
        const urlParams = new URLSearchParams(queryString);
        const paramValue = urlParams.get('test');
        
        if (paramValue) {
            document.getElementById('testinput').innerHTML = paramValue;
        }
    </script>
</main>

<?php include_once PUBLIC_PHP_PATH.'footer.php'; ?>
