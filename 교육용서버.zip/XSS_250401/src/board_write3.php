<?php    
    include 'common.php'; 
    include PUBLIC_PHP_PATH.'header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/public/css/style.css">
    <title>게시글 작성</title>
    <style>
        body {
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .detail-container {
            width: 50%;
            margin: 50px auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        .detail-container h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
            display: block;
            margin-bottom: 8px;
            color: #555;
        }

        input[type="text"],
        textarea {
            font-family: 'AppleSDGothicNeoR00', 'Arial', sans-serif;
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #333;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #555;
        }
    </style>
</head>
<body>
    <div class="search-container">
        <h2>게시글 작성</h2>
    </div>
    <div class="detail-container">
        <form action="write_post3.php" method="post">
            <label for="subject">제목:</label>
            <input type="text" name="subject" id="subject" required>

            <label for="content">내용:</label>
            <textarea name="content" id="content" rows="8" required></textarea>

            <div class="button-group">
                <input type="submit" class="button" value="게시글 작성">
            </div>
        </form>
    </div>
</body>
</html>

<?php include PUBLIC_PHP_PATH.'footer.php'; ?>
