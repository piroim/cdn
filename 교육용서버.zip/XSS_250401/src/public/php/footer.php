<footer>
    <p>&copy; 2025 Security Academy 5기 - 임필호</p>
</footer>