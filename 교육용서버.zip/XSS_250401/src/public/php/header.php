<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>시큐리티 아카데미 5기</title>
        <link rel="stylesheet" href="/public/css/style.css">
        <link rel="stylesheet" href="/public/css/board.css">
    </head>
    <body>
        <header>
            <h1>[실습] Cross Site Scripting</h1>
        </header>
        <nav>
            <ul>
                <li><a href="/">메인</a></li>
                <li><a href="board.php">실습1</a></li>
                <li><a href="board2.php">실습2</a></li>
                <li><a href="board3.php">게시판3</a></li>
                <li><a href="board4.php">게시판4</a></li>
                <li><a href="board5.php">게시판5</a></li>
                <?php if(isset($_SESSION['username'])): ?>
                    <li><a href="logout.php">로그아웃</a></li>
                    <li><a href="user_info.php">회원정보</a></li>
                <?php else: ?>
                    <li><a href="login.php">로그인</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </body>
</html>