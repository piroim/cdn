<?php
    function filter1($content) {
        $content = preg_replace('/script/i', '', $content);
        return $content;
    }

    function filter2($content) {
        $content = preg_replace('/script/i', '', $content);
        $content = preg_replace('/img/i', '', $content);
        $content = preg_replace('/on/i', '', $content);
        $content = preg_replace('/alert/i', '', $content);
        return $content;
    }
?>

