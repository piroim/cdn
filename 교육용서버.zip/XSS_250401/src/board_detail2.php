<?php
include 'common.php';

include_once PUBLIC_PHP_PATH.'header.php';

/*DB에서 게시글 정보 가져오기*/
if(isset($_GET['no'])) {
    $no = htmlspecialchars($_GET['no']);
    $sql = $db_conn->prepare("SELECT * FROM board2 WHERE no = ?");
    $sql->bind_param("i", $no);
    $sql->execute();
    $result = $sql->get_result();

    if($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    }
}
/*게시글 삭제 */
if(isset($_POST['delete']) && isset($_POST['no'])) {
    $no = $_POST['no'];
    $sql = $db_conn->prepare("DELETE FROM board2 WHERE no = ?");
    $sql->bind_param("i", $no);
    $sql->execute();
    header("Location: board2.php");
    exit();
}
?>
<main>
    <div class="detail-container">
    <div class="title"><?php echo $row["subject"]; ?></div>
    <div class="content"><?php echo $row["content"]; ?></div>
    <div class="time"><?php echo $row["date"]; ?></div>
    <div class="button-group">

    <form id="deleteForm" action="board_detail2.php" method="post">
        <input type="hidden" name="no" value="<?php echo $no; ?>">
        <input type="hidden" name="delete" value="1">
    </form>

    <a href="javascript:void(0);" onclick="confirmDelete()" class="button">삭제</a>
    <a href="/board2.php" class="button">목록</a>

    </div>
    </div>
</main>

<script>
    function confirmDelete() {
        if(confirm('정말로 삭제하시겠습니까?')) {
            document.getElementById('deleteForm').submit();
        }
    }
</script>

<?php  include_once PUBLIC_PHP_PATH.'footer.php'; ?>