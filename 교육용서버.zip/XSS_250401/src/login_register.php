<?php
    include 'common.php';
    include_once PUBLIC_PHP_PATH.'header.php';
?>
<main>
    회원가입 기능 구현 중입니다.
    
</main>

<?php include_once PUBLIC_PHP_PATH.'footer.php'; ?>

