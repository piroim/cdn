CREATE TABLE security_user(
    no int not null auto_increment,
    name VARCHAR(30) NOT NULl,
    password VARCHAR(30) NOT NUll,
    PRIMARY KEY(no)
);

CREATE TABLE board(
    no int not null auto_increment,
    subject VARCHAR(30) NOT NULl,
    writer VARCHAR(30),
    content VARCHAR(1000) NOT NULL,
    date DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY(no)
);

CREATE TABLE board2(
    no int not null auto_increment,
    subject VARCHAR(30) NOT NULl,
    writer VARCHAR(30),
    content VARCHAR(1000) NOT NULL,
    date DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY(no)
);

CREATE TABLE board3(
    no int not null auto_increment,
    subject VARCHAR(30) NOT NULl,
    writer VARCHAR(30),
    content VARCHAR(1000) NOT NULL,
    date DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY(no)
);

CREATE TABLE board4(
    no int not null auto_increment,
    subject VARCHAR(30) NOT NULl,
    writer VARCHAR(30),
    content VARCHAR(1000) NOT NULL,
    date DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY(no)
);

INSERT INTO security_user(name, password) VALUES
    ("guest", "guest"),
    ("guest1", "guest1"),
    ("guest2", "guest2"),
    ("guest3", "guest3"),
    ("guest4", "guest4"),
    ("guest5", "guest5"),
    ("guest6", "guest6"),
    ("guest7", "guest7"),
    ("guest8", "guest8"),
    ("guest9", "guest9"),
    ("guest10", "guest10"),
    ("guest11", "guest11"),
    ("guest12", "guest12"),
    ("guest13", "guest13"),
    ("guest14", "guest14"),
    ("guest15", "guest15"),
    ("guest16", "guest16"),
    ("guest17", "guest17"),
    ("guest18", "guest18"),
    ("guest19", "guest19"),
    ("guest20", "guest20"),
    ("guest21", "guest21"),
    ("guest22", "guest22"),
    ("guest23", "guest23"),
    ("guest24", "guest24"),
    ("guest25", "guest25"),
    ("guest26", "guest26"),
    ("guest27", "guest27"),
    ("guest28", "guest28"),
    ("guest29", "guest29"),
    ("guest30", "guest30"),
    ("admin", "sa2024admin");

ALTER TABLE board CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE board2 CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE board3 CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE board4 CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

INSERT INTO board(subject, writer, content) VALUES
    ("Example","guest1","Example Content"),
    ("Example","guest2","Example Content"),
    ("Example","guest3","Example Content"),
    ("Example","guest4","Example Content"),
    ("Example","guest5","Example Content"),
    ("Example","guest6","Example Content"),
    ("Example","guest7","Example Content"),
    ("Example","guest8","Example Content"),
    ("Example","guest9","Example Content"),
    ("Example","guest10","Example Content"),
    ("Example","guest11","Example Content"),
    ("Example","guest12","Example Content"),
    ("Example","guest13","Example Content"),
    ("Example","guest14","Example Content"),
    ("Example","guest15","Example Content"),
    ("Example","guest17","Example Content"),
    ("Example","guest18","Example Content"),
    ("Example","guest19","Example Content"),
    ("Example","guest20","Example Content"),
    ("Example","guest21","Example Content"),
    ("Example","guest22","Example Content"),
    ("Example","guest23","Example Content"),
    ("Example","guest24","Example Content"),
    ("Example","guest25","Example Content"),
    ("Example","guest26","Example Content"),
    ("Example","guest27","Example Content"),
    ("Example","guest28","Example Content"),
    ("Example","guest29","Example Content"),
    ("Example","guest30","Example Content");