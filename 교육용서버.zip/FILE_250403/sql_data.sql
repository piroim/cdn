CREATE TABLE security_user(
    no int not null auto_increment,
    name VARCHAR(30) NOT NULl,
    password VARCHAR(30) NOT NUll,
    email VARCHAR(100),
    PRIMARY KEY(no)
);

CREATE TABLE level1(
    no int not null auto_increment,
    id VARCHAR(30) NOT NULl,
    pass VARCHAR(30) NOT NUll,
    PRIMARY KEY(no)
);

INSERT INTO security_user(name, password, email) VALUES
    ("guest", "guest", "guest@gmail.com"),
    ("guest1", "guest1", "guest1@naver.com"),
    ("guest2", "guest2", "guest2@naver.com"),
    ("guest3", "guest3", "guest3@security.com"),
    ("admin", "admin", "admin@gmail.com");

INSERT INTO level1(id, pass) VALUES
    ("user1", "pwuser1"),
    ("user2", "pwuser2"),
    ("user3", "pwuser3"),
    ("user4", "pwuser4"),
    ("admin", "admin1");