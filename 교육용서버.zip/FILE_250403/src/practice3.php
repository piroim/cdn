<?php
    include 'common.php';
    include_once PUBLIC_PHP_PATH.'header.php';
    //Error 출력코드
    ini_set('display_errors', 0);
    mysqli_report(MYSQLI_REPORT_ERROR);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>File Viewer</title>
</head>
<body>
    <div class="search-container">
        <h2>[Remote File Inclusion] 파일 조회</h2>
    </div>
    <div>
        <h3><a href="?file=file1.php">내 IP 조회</a></h3>
        <h3><a href="?file=file2.php">이미지 조회</a></h3>
        <h3><a href="?file=file3.php">방명록</a></h3>
    </div>
    <div class="output">
        <?php
            if (isset($_GET['file'])) {
                $file = $_GET['file'];

                if (strpos($file, 'file:') !== false) {
                    echo "잘못된 입력입니다. 파일 포함을 시도하지 마세요.";
                } else {
                    include($file);
                }
            } else {
                echo "기능을 선택해주세요.";
            }
        ?>
    </div>
</body>
</html>

<?php include_once PUBLIC_PHP_PATH.'footer.php'; ?>