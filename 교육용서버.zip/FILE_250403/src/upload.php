<?php
    include 'common.php';
    include_once PUBLIC_PHP_PATH.'header.php';
    
    // 설정: 업로드할 디렉토리
    $target_dir = "/public/uploads/";
    // 파일의 최종 경로와 파일명을 지정
    $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
    $uploadOk = 1;

    // 파일 업로드 처리
    if (isset($_POST["submit"])) {
        // 파일을 지정된 경로로 이동
        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
            echo "The file " . htmlspecialchars(basename($_FILES["fileToUpload"]["name"])) . " has been uploaded.";
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }
?>
