<?php 
    echo "조회된 IP 정보 : ";
    $userIP = $_SERVER['REMOTE_ADDR'];
    echo $userIP;
?>