<?php ?>

<!DOCTYPE html>
<html>
    <head>
    </head>
<body>
    <?php
    session_start(); // 세션 시작

    if (isset($_POST['reset'])) {
        // 세션에서 댓글 데이터 제거
        unset($_SESSION["comments"]);
    }

    // 폼 제출 시 댓글 처리
    if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST["comment"])) {
        $new_comment = htmlspecialchars($_POST["comment"]);
        // 세션에 댓글 배열이 존재하지 않으면 생성
        if (!isset($_SESSION["comments"])) {
            $_SESSION["comments"] = [];
        }
        // 새 댓글을 세션 배열에 추가
        $_SESSION["comments"][] = $new_comment;
    }
    ?>

    환영합니다. 방명록을 작성해주세요.
    <form method="post" action="practice2.php?file=file3.php">
        <input type="text" class="search-box" id="comment" name="comment" placeholder="글 작성 후, Enter를 입력하세요." autofocus><br>
        <button class="button" type="submit">댓글작성</button>
        <button class="button" type="submit" name="reset" style="margin-left: 20px;">초기화</button>
    </form>

    <?php
    // 저장된 댓글 출력
    if (isset($_SESSION["comments"])) {
        echo "<br><h4> 작성된 방명록</h4><br>";
        foreach ($_SESSION["comments"] as $comment) {
            echo "<p>$comment</p>";
        }
    }
    ?>
</body>
</html>
