<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Security Academy</title>
        <link rel="stylesheet" href="/public/css/style.css">
        <link rel="stylesheet" href="/public/css/board.css">
        <link rel="stylesheet" href="/public/css/practice.css">
    </head>
    <body>
        <header>
            <a href="/index.php" style="text-decoration: none;"><h1>[실습] File Vulnerability</h1></a>
        </header>
        <nav>
            <ul>
                <li><a href="/">메인</a></li>
                <li><a href="practice.php">실습1</a></li>
                <li><a href="practice1.php">실습1-1</a></li>
                <li><a href="practice2.php">실습2</a></li>
                <li><a href="practice3.php">실습3</a></li>
                <li><a href="practice4.php">실습4</a></li>
                <li><a href="practice5.php">실습5</a></li>
            </ul>
        </nav>
    </body>
</html>