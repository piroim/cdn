<?php
    session_start();
    define('PUBLIC_PHP_PATH', './public/php/');
    include 'db.php';
    // $flag = file_get_contents('/flag');
    
    function filter_1($keyword) {
        //board keyword
        $keyword = preg_replace('/(script|img|svg|iframe|frameset|frame|body|focus)/i', '_', $keyword);
        return $keyword;
    }

    function filter_2($keyword) {
        //login hidden
        $keyword = preg_replace('/("|java|script|svg|iframe|frameset|frame|location|video|alert|prompt|print|body)/i', '_', $keyword);
        $keyword = preg_replace('/on/i', '', $keyword);
        return $keyword;
    }

    function filter_3($keyword) {
        //board write post
        $keyword = preg_replace('/("|img|svg|iframe|frameset|frame|atob|http|\/|video|\()/i', '_', $keyword);
        $keyword = preg_replace('/on\w*?\s*?=\s*?[\'"]?\s*?location\.href\s*?=.*?[\'"]/i', '_', $keyword);
        return $keyword;
    }

    function filter_4($keyword) {
        //user info
        $keyword = preg_replace('/(\'|>|<|img|svg|alert|prompt|iframe|frameset|frame|location|http|\/|video|body)/i', '_', $keyword);
        return $keyword;
    }
    
?>