<?php
ob_start();  // 버퍼링 시작
include 'common.php';
include_once PUBLIC_PHP_PATH.'header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
</head>
<body>
    <div class="search-container">
        <h2>[File Download] 다운로드 게시판</h2>
    </div>

    <?php
        if (isset($_GET['file'])) {
            $file = $_GET['file'];
            $filepath = "/var/www/html/uploads/" . $file;
            $fileExtension = strtolower(pathinfo($filepath, PATHINFO_EXTENSION));

            // 실행 가능한 파일 확장자 목록
            $deniedExtensions = ['php', 'exe', 'sh', 'bat', 'js', 'html', 'htm', 'py', 'pl'];

            if (in_array($fileExtension, $deniedExtensions)) {
                // echo "<h4 style='color: #C00000;'>요청 파일이 없거나 다운로드 할 수 없습니다.</h4>";
                die('<h4 style="color: #C00000;">[Access Denied] 확장자 있는 파일은 다운로드하지 말아주세요.</h4>');
            }
            
            if (file_exists($filepath)) {
                // 파일 전송을 위한 헤더 설정
                header('Content-Description: File Transfer');
                header('Content-Type: application/octet-stream');
                header('Content-Disposition: attachment; filename="' . basename($filepath) . '"');
                header('Expires: 0');
                header("Content-Transfer-Encoding: binary");
                header('Cache-Control: must-revalidate');
                header('Pragma: public');
                header('Content-Length: ' . filesize($filepath));
                
                ob_end_clean();  // 현재 버퍼를 비우고 출력 버퍼링 종료
                readfile($filepath);  // 파일 읽어서 전송
                exit;  // 파일 다운로드 후 스크립트 종료
            } else {
                echo "<h4 style='color: #C00000;'>요청 파일이 없거나 다운로드 할 수 없습니다.</h4>";
            }
        }
    ?>

    <br>
    <div class="search-container">
        <h4>저장된 이미지</h4><br>
        <table>
            <thead>
                <tr>
                    <th>파일명</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $dir = "/var/www/html/uploads/";
                    if ($dh = opendir($dir)) {
                        while (($file = readdir($dh)) !== false) {
                            if ($file != "." && $file != ".." && !is_dir($dir . $file)) {
                                echo "<tr><td><a href='?file=" . urlencode($file) . "'>" . htmlspecialchars($file) . "</a></td>";
                            }
                        }
                        closedir($dh);
                    }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>

<?php include_once PUBLIC_PHP_PATH.'footer.php'; ?>
