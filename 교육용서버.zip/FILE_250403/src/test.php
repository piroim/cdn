<?php
    echo "LFI include TEST";
?>