<?php
    ob_start();
    include 'common.php';
    include_once PUBLIC_PHP_PATH.'header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
</head>
<body>
    <div class="search-container">
        <h2>[File Download] 이미지 게시판</h2>
    </div>

    <?php
        if (isset($_GET['file'])) {
            $file = $_GET['file'];
            $filepath = "/var/www/html/uploads/" . $file;
        
            if (file_exists($filepath)) {
                header('Content-Description: File Transfer');
                header('Content-Type: application/octet-stream');
                header('Content-Disposition: attachment; filename="' . basename($filepath) . '"');
                header('Expires: 0');
                header("Content-Transfer-Encoding: binary");
                header('Cache-Control: must-revalidate');
                header('Pragma: public');
                header('Content-Length: ' . filesize($filepath));
                ob_clean();  // 현재 버퍼를 정리
                flush();     // 시스템 출력 버퍼를 비움
                
                $ch = curl_init();

                curl_setopt($ch, CURLOPT_HEADER, 0);
                curl_setopt($ch, CURLOPT_URL, $filepath);

                $file = curl_exec ($ch);
                curl_close($ch);
                exit;
            } else {
                echo "<p>요청하신 파일은 다운로드할 수 없습니다.</p>";
            }
        }
    ?>

    <br>
    <div class="search-container">
        <h3>저장된 이미지</h3>
        <table>
            <thead>
                <tr>
                    <th>파일명</th>
                    <th>삭제</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    ob_start();
                    $dir = "/var/www/html/uploads/";
                    if ($dh = opendir($dir)) {
                        while (($file = readdir($dh)) !== false) {
                            if ($file != "." && $file != ".." && !is_dir($dir . $file)) {
                                $filePath = $dir . $file;
                                $fileSize = filesize($filePath);
                                echo "<tr><td><a href='?file=" . urlencode($file) . "'>" . htmlspecialchars($file) . "</a></td>";
                                echo "<td><a href='?delete=" . urlencode($file) . "' onclick=\"return confirm('이미지를 삭제하시겠습니까?');\">Delete</a></td></tr>";
                            }
                        }
                        closedir($dh);
                    }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>

<?php include_once PUBLIC_PHP_PATH.'footer.php'; ?>
