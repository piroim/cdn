<?php
    include 'common.php';
    include_once PUBLIC_PHP_PATH.'header.php';
    //Error 출력코드
    ini_set('display_errors', 0);
    mysqli_report(MYSQLI_REPORT_ERROR);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
</head>
<body>
    <div class="search-container">
        <h2>[Path Traversal] 이미지 게시판</h2>
        <!-- <form action="" method="post" enctype="multipart/form-data">
            <label for="fileToUpload">이미지 파일 업로드 : </label>
            <input type="file" name="fileToUpload" id="fileToUpload">
            <input type="submit" value="업로드" name="submit">
        </form> -->
    </div>

    <?php
        $dir = "uploads/";
        if (!is_dir($dir)) {
            mkdir($dir); // Ensure the directory exists
        }

        if (isset($_POST['submit'])) {
            $fileToUpload = $_FILES['fileToUpload'];
            if ($fileToUpload['error'] == UPLOAD_ERR_OK) {
                $tmp_name = $fileToUpload['tmp_name'];
                $filename = basename($fileToUpload['name']);
                $target_file = $dir . $filename;

                if (move_uploaded_file($tmp_name, $target_file)) {
                    echo "<script>alert('파일 업로드에 성공하였습니다.')</script>";
                } else {
                    echo "<p>파일 업로드에 실패하였습니다.</p>";
                }
            }
        }

        if (isset($_GET['file'])) {
            $file = $_GET['file'];
            $filePath = $dir . $file; // Prevent directory traversal
            // var_dump($filePath);
            if (file_exists($filePath)) {
                echo "<p align='center'>파일경로 : <span style='color: #C00000; font-weight: bold;'>" . htmlspecialchars(realpath($filePath)) . "</span></p>";


                echo "<h3 align=center>선택한 이미지 출력</h3>";
                echo "<p align=center>" . htmlspecialchars(file_get_contents($filePath)) . "</p>";
                echo "<img src='" . htmlspecialchars($filePath) . "' alt='" . htmlspecialchars($file) . "' style='max-width: 20%; display: block; margin-left: auto; margin-right: auto;'/>";
            } else {
                echo "<h3 align=center style='color: #C00000;' >이미지가 존재하지 않습니다.</h3>";
            }
        }
    ?>

    <br>
    <div class="search-container">
        <h3>저장된 이미지</h3>
        <table>
            <thead>
                <tr>
                    <th>파일명</th>
                    <th>크기</th>
                    <!-- <th>삭제</th> -->
                </tr>
            </thead>
            <tbody>
                <?php
                    // Check if file deletion has been requested
                    if (isset($_GET['delete'])) {
                        $fileToDelete = $dir . basename($_GET['delete']);
                        if (file_exists($fileToDelete)) {
                            unlink($fileToDelete);  // Delete the file
                            echo "<p>File deleted successfully.</p>";
                        } else {
                            echo "<p>File does not exist.</p>";
                        }
                    }

                    if ($dh = opendir($dir)) {
                        while (($file = readdir($dh)) !== false) {
                            if ($file != "." && $file != ".." && !is_dir($dir . $file)) {
                                $filePath = $dir . $file;
                                $fileSize = filesize($filePath);
                                echo "<tr><td><a href='?file=" . urlencode($file) . "'>" . htmlspecialchars($file) . "</a></td>";
                                echo "<td>" . formatSizeUnits($fileSize) . "</td>";
                                // echo "<td><a href='?delete=" . urlencode($file) . "' onclick=\"return confirm('이미지를 삭제하시겠습니까?');\">Delete</a></td><tr>";
                            }
                        }
                        closedir($dh);
                    }

                    function formatSizeUnits($bytes) {
                        if ($bytes >= 1073741824) {
                            $bytes = number_format($bytes / 1073741824, 2) . ' GB';
                        } elseif ($bytes >= 1048576) {
                            $bytes = number_format($bytes / 1048576, 2) . ' MB';
                        } elseif ($bytes >= 1024) {
                            $bytes = number_format($bytes / 1024, 2) . ' KB';
                        } else if ($bytes > 1) {
                            $bytes = $bytes . ' bytes';
                        } elseif ($bytes == 1) {
                            $bytes = $bytes . ' byte';
                        } else {
                            $bytes = '0 bytes';
                        }
                        return $bytes;
                    }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>


<?php include_once PUBLIC_PHP_PATH.'footer.php'; ?>