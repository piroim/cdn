<?php
    $dir = 'uploads/';  // 이미지 파일들이 저장된 디렉토리

    // 디렉토리를 열고 파일 목록을 읽습니다
    if (is_dir($dir)) {
        if ($dh = opendir($dir)) {
            echo "<div style='text-align: center; overflow-x: auto; white-space: nowrap;'>
            ";
            while (($file = readdir($dh)) !== false) {
                // 파일 확장자를 확인하여 이미지 파일만 표시합니다
                if (preg_match('/\.(jpg|jpeg|png|gif)$/i', $file)) {
                    echo "<img src='" . htmlspecialchars($dir . $file) . "' alt='" . htmlspecialchars($file) . "' style='max-width: 100px; margin: 10px;'><br>";
                }
            }
            echo "</div>";
            closedir($dh);
        }
    } else {
        echo "<p>디렉토리가 존재하지 않습니다.</p>";
    }
?>