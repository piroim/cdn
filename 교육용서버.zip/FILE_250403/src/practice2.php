<?php
    include 'common.php';
    include_once PUBLIC_PHP_PATH.'header.php';
    //Error 출력코드
    ini_set('display_errors', 0);
    mysqli_report(MYSQLI_REPORT_ERROR);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>File Viewer</title>
</head>
<body>
    <div class="search-container">
        <h2>[Local File Inclusion] 파일 조회</h2>
    </div>
    <div>
        <h3><a href="?file=file1.php">내 IP 조회</a></h3>
        <h3><a href="?file=file2.php">이미지 조회</a></h3>
        <h3><a href="?file=file3.php">방명록</a></h3>
    </div>
    <div class="output">
        <?php
            if (isset($_GET['file'])) {
                $file = $_GET['file'];

                // URL 검증: http:// 또는 https://로 시작하는 URL 차단
                if (preg_match('/^https?:\/\//i', $file)) {
                    echo "<h3 style='color: #C00000;'>외부 URL은 허용되지 않습니다.</h3>";
                } else {
                    include($file);  // 파일 포함
                }
            } else {
                echo "기능을 선택해주세요."; // 초기 메시지
            }
        ?>
    </div>
</body>
</html>

<?php include_once PUBLIC_PHP_PATH.'footer.php'; ?>