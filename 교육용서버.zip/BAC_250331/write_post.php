<?php
    include 'common.php';
    include PUBLIC_PHP_PATH.'filter.php';

    if($_SERVER["REQUEST_METHOD"] == "POST") {
        if(!isset($_SESSION['username'])) {
            echo "<script>alert('로그인 후, 오세용');</script>";
            echo "<script>window.location.href='login.php';</script>";
            exit();
        }

        $subject = filter_3($_POST['subject']);
        $writer = $_SESSION['username'];
        $content = filter_3($_POST['content']);

        // $subject = $_POST['subject'];
        // $writer = $_SESSION['username'];
        // $content = $_POST['content'];

        $result = $db_conn->prepare("INSERT INTO board(subject, writer, content) VALUES (?,?,?)");
        $result->bind_param("sss",$subject, $writer, $content);

        if($result->execute()) {
            echo "<script>alert('게시글 작성 완료!');</script>";
            echo "<script>window.location.href = 'board.php';</script>";
        } 
        
        else {
            echo "<script>alert('게시글 작성에 실패!');</script>";
            echo "<script>window.location.href = 'board.php';</script>";
        }
        $db_conn->close();
    }
?>