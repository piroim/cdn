<?php
include 'common.php'; 

// POST로 전달된 데이터 받기
$no = htmlspecialchars($_POST['no']); // 수정할 게시글 ID
$subject = htmlspecialchars($_POST['subject']); // 수정된 제목
$content = htmlspecialchars($_POST['content']); // 수정된 내용

// 데이터 검증 (필수적인 데이터가 존재하는지 확인)
if (empty($no) || empty($subject) || empty($content)) {
    echo "<script>alert('필수 입력값이 누락되었습니다.');
            window.history.back();</script>";
    exit;
}

// 데이터베이스에 수정된 데이터를 반영하는 SQL
$sql = "UPDATE board3 SET subject = ?, content = ? WHERE no = ?";
$stmt = $db_conn->prepare($sql);
$stmt->bind_param("ssi", $subject, $content, $no);

// 업데이트가 성공했는지 확인
if ($stmt->execute()) {
    echo "<script>alert('게시글이 성공적으로 수정되었습니다.');
            window.location.href='/board3.php';</script>"; // 수정 후 게시글 목록으로 리디렉션
} else {
    echo "<script>alert('게시글 수정 중 오류가 발생했습니다.');
            window.history.back();</script>"; // 오류 발생 시 이전 페이지로 돌아감
}

$stmt->close();
$db_conn->close();
?>
