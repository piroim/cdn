<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Security Academy</title>
        <link rel="stylesheet" href="/public/css/style.css">
        <link rel="stylesheet" href="/public/css/board.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    </head>
    <body>
        <header>
            <a href="/index.php" style="text-decoration: none;"><h1>[실습] Broken Access Control</h1></a>
        </header>
        <nav>
            <ul>
                <li><a href="/">메인</a></li>
                <li><a href="practice.php">실습</a></li>
                <li><a href="board.php">실습2</a></li>
                <li><a href="board2.php">실습3</a></li>
                <li><a href="board3.php">실습4</a></li>
                <?php if(isset($_SESSION['username'])): ?>
                    <li><a href="logout.php">로그아웃</a></li>
                    <li><a href="user_info.php">회원정보</a></li>
                <?php else: ?>
                    <li><a href="login.php">로그인</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </body>
</html>