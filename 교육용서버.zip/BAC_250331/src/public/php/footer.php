<footer>
    <p>&copy; 2025 Security Academy - piroim</p>
</footer>