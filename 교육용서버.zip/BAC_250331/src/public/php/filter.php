<?php
    function xss_filter($content) {
        $content = preg_replace('/[iI][mM][gG]/', '_', $content);
        $content = preg_replace('/[sS][rR][cC]/', '_', $content);
        $content = preg_replace('/[iI][fF][rR][aA][mM][eE]/', '_', $content);
        return $content;
    }
?>