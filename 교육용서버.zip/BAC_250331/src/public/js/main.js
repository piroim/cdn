document.addEventListener("DOMContentLoaded", () => {
    const posts = [
        { title: "📌 신규 기능 안내", content: "2025년 봄 정기 업데이트가 진행되었습니다." },
        { title: "🛠️ 서버 점검 공지", content: "3월 31일 02:00~04:00 동안 서비스가 중단됩니다." },
        { title: "🎉 회원 수 2,000명 돌파!", content: "모두 감사드립니다!" }
    ];

    const postContainer = document.getElementById("posts");
    postContainer.innerHTML = "";

    posts.forEach(post => {
        const div = document.createElement("div");
        div.classList.add("post");
        div.innerHTML = `<h3>${post.title}</h3><p>${post.content}</p>`;
        postContainer.appendChild(div);
    });
});
