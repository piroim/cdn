console.log("🚨 admin.js loaded");

//Only Admin 
window.__ADMIN_INTERFACE__ = {
    dashboard: "/admin/dashboard.php",
    users: "/admin/users.php",
    settings: "/admin/settings.php",
    logs: "/admin/logs.php",
    debug: true
};
