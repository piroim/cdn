<?php
    echo "<script>alert('수정할 수 없습니다.');
            window.location.href='/board2.php';</script>";
?>