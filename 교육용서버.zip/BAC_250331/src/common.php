<?php
    session_start();
    define('PUBLIC_PHP_PATH', './public/php/');
    define('JS_PATH', '/public/js/');
    include 'db.php';
?>