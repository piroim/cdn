<?php
    include 'common.php';
    include_once PUBLIC_PHP_PATH.'header.php';

    //Error 출력코드
    ini_set('display_errors', 1);
    mysqli_report(MYSQLI_REPORT_ERROR);
    $userInfo1 = "";
    $userInfo2 = "";
    $userInfo3 = "";

    // 로그인한 사용자의 정보 가져오기
    if (isset($_SESSION['username'])) {
        $loggedInUser = $_SESSION['username'];

        // 로그인한 사용자의 no 값을 가져오는 쿼리
        $query = "SELECT no FROM security_user WHERE name = ?";
        if ($stmt = $db_conn->prepare($query)) {
            $stmt->bind_param("s", $loggedInUser);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($row = $result->fetch_assoc()) {
                $loggedInUserId = $row['no'];
            } 
            $stmt->close();
        }

        // userid 파라미터가 없을 경우 자동으로 붙이기
        if (!isset($_GET['userid'])) {
            // 현재 URL을 가져와서 userid 파라미터를 추가
            $currentUrl = $_SERVER['REQUEST_URI'];
            $separator = strpos($currentUrl, '?') === false ? '?' : '&';
            header("Location: " . $currentUrl . $separator . "userid=" . $loggedInUserId);
            exit;
        }
    }

    // GET 요청 처리
    if (isset($_GET['userid'])) {
        $userid = $_GET['userid'];

        // 전체 계정 수 확인
        $count_query = "SELECT COUNT(*) as total FROM security_user";
        $count_result = $db_conn->query($count_query);
        $total_users = $count_result->fetch_assoc()['total'];

        // userid가 전체 계정 수보다 크면 0으로 설정 (존재하지 않는 계정)
        if ($userid > $total_users) {
            $userid = 0;
        }

        $query = "SELECT * FROM security_user WHERE no = ?";
        if ($stmt = $db_conn->prepare($query)) {
            $stmt->bind_param("i", $userid);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($row = $result->fetch_assoc()) {
                $userInfo1 = $row['name'];
                $userInfo2 = $row['password'];
                $userInfo3 = $row['email'];
            } 
            else {
                $userInfo1 = "이용자 정보가 없습니다.";
                $userInfo2 = "이용자 정보가 없습니다.";
                $userInfo3 = "이용자 정보가 없습니다.";
            }
            $stmt->close();
        }
    }
?>

<html>
    <head><style></style></head>
    <body>
        <div class="search-container">
            <h2>[IDOR] 내 정보 조회</h2>
            <h3>
                <?php
                    if($userInfo1 == 'admin') {
                        echo "<p style='color:#C00000;'>조회한 이용자 정보</p>";
                        echo "<p style='color:#C00000;'>계정명 : $userInfo1</p>";
                        echo "<p style='color:#C00000;'>비밀번호 : $userInfo2</p>"; 
                        echo "<p style='color:#C00000;'>이메일 : $userInfo3</p>"; 
                        echo "<br><p style='color:#C00000;'>관리자 정보가 조회되었습니다!</p>";
                    }
                    else {
                        echo "<p>조회한 이용자 정보</p>";
                        echo "<p>계정명 : $userInfo1</p>";
                        echo "<p>비밀번호 : $userInfo2</p>"; 
                        echo "<p>이메일 : $userInfo3</p>"; 
                    }
                ?>
            <h3>
        </div>
        
        <br>
        <div class="search-container">
            <!-- <h2>1</h2> -->
        </div>
    </body>
</html>

<?php include_once PUBLIC_PHP_PATH.'footer.php'; ?>
