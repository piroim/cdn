<?php
    include 'common.php';
    include 'login_process.php';
    include_once PUBLIC_PHP_PATH.'header.php';

    if (isset($_SESSION['start_time'])) {
        $elapsed_time = time() - $_SESSION['start_time'];
        $remaining_time = $_SESSION['expire_time'] - $elapsed_time;
    
        if ($remaining_time > 0) {
            echo "<div class='session-timer'>남은 세션 시간: <span id='timer'>" . $remaining_time . "</span></div>";
            echo "<script>var remainingTime = $remaining_time;</script>";
        } else {
            echo "<script>alert('로그아웃 되었습니다.')</script>";
            session_destroy();
        }
    } else {
        echo "<div class='alert'>로그인되지 않음</div>";
    }
?>

<main class="user-info-container">
    <div class="user-profile-card">
        <div class="profile-header">
            <div class="profile-avatar">
                <i class="fas fa-user-circle"></i>
            </div>
            <h1>사용자 프로필</h1>
            <p class="welcome-message">안녕하세요, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong>님!</p>
        </div>
        
        <div class="profile-content">
            <div class="info-section">
                <h2><i class="fas fa-info-circle"></i> 세션 정보</h2>
                <div class="info-grid">
                    <?php foreach ($_SESSION as $key => $value): ?>
                        <div class="info-item">
                            <span class="info-label"><?php echo htmlspecialchars($key); ?></span>
                            <span class="info-value"><?php echo htmlspecialchars($value); ?></span>
                        </div>
                    <?php endforeach; ?>
                    <div class="info-item">
                        <span class="info-label">PHPSESSID</span>
                        <span class="info-value"><?php echo session_id(); ?></span>
                    </div>
                </div>
            </div>

            <div class="action-section">
                <form action="logout.php" method="post">
                    <button type="submit" class="logout-button">
                        <i class="fas fa-sign-out-alt"></i> 로그아웃
                    </button>
                </form>
            </div>
        </div>
    </div>
</main>

<?php include_once PUBLIC_PHP_PATH.'footer.php'; ?>

<script>
    function updateTimer() {
        if (remainingTime > 0) {
            remainingTime--;
            var minutes = Math.floor(remainingTime / 60);
            var seconds = remainingTime % 60;
            document.getElementById('timer').textContent = minutes + "분 " + seconds + "초";
        } else {
            clearInterval(timerInterval);
            document.getElementById('timer').textContent = "세션 만료";
        }
    }

    var timerInterval = setInterval(updateTimer, 1000);
    var sessionId = "<?php echo session_id(); ?>";
</script>

<style>
    .user-info-container {
        max-width: 800px;
        margin: 40px auto;
        padding: 0 20px;
    }

    .user-profile-card {
        background: white;
        border-radius: 16px;
        box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);
        overflow: hidden;
        transition: transform 0.3s ease;
    }

    .user-profile-card:hover {
        transform: translateY(-5px);
    }

    .profile-header {
        background: #000000;
        color: white;
        padding: 30px 20px;
        text-align: center;
    }

    .profile-avatar {
        font-size: 48px;
        margin-bottom: 15px;
        color: rgba(255, 255, 255, 0.9);
    }

    .profile-header h1 {
        margin: 0;
        font-size: 22px;
        font-weight: 600;
        color: white;
    }

    .welcome-message {
        margin: 8px 0 0;
        font-size: 15px;
        opacity: 0.9;
        color: white;
    }

    .profile-content {
        padding: 30px;
    }

    .info-section {
        margin-bottom: 30px;
    }

    .info-section h2 {
        color: #1f2937;
        font-size: 18px;
        margin-bottom: 20px;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .info-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
    }

    .info-item {
        background: #f9fafb;
        padding: 15px;
        border-radius: 8px;
        display: flex;
        flex-direction: column;
        gap: 5px;
    }

    .info-label {
        color: #6b7280;
        font-size: 14px;
    }

    .info-value {
        color: #1f2937;
        font-size: 16px;
        font-weight: 500;
        word-break: break-all;
    }

    .action-section {
        text-align: center;
        margin-top: 30px;
    }

    .logout-button {
        background: #000000;
        color: white;
        border: none;
        padding: 12px 24px;
        border-radius: 8px;
        font-size: 16px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        transition: all 0.3s ease;
    }

    .logout-button:hover {
        background: #000000;
        transform: translateY(-2px);
    }

    .session-timer {
        background: #f3f4f6;
        color: #1f2937;
        padding: 12px;
        border-radius: 8px;
        text-align: center;
        font-size: 16px;
        margin-bottom: 20px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
    }

    .alert {
        background: #fee2e2;
        color: #dc2626;
        padding: 12px;
        border-radius: 8px;
        text-align: center;
        font-size: 16px;
        margin-bottom: 20px;
    }

    @media (max-width: 640px) {
        .user-info-container {
            margin: 20px auto;
        }

        .profile-header {
            padding: 30px 15px;
        }

        .profile-content {
            padding: 20px;
        }

        .info-grid {
            grid-template-columns: 1fr;
        }
    }
</style>
