<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>관리자 페이지</title>
</head>
<body>
    <h1>관리자만 접근할 수 있습니다.</h1>

    <!-- admin.js 클라이언트에 노출 -->
    <script src="/public/js/admin.js"></script>
</body>
</html>