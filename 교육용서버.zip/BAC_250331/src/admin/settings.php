<?php
echo "<h1>🔧 시스템 설정 정보</h1>";
echo "<table border='1' cellpadding='8' cellspacing='0'>";

$settings = [
    "운영 모드" => "production",
    "서버 버전" => "Apache/2.4.54 (Debian)",
    "PHP 버전" => "8.1.22",
    "MySQL 호스트" => "mysql.internal.local",
    "MySQL 사용자" => "root",
    "MySQL 비밀번호" => "rootpass123!",
    "SMTP 서버" => "smtp.sesacmail.com",
    "SMTP 포트" => "587",
    "SMTP 사용자" => "noreply@sesacmail.com",
    "SMTP 비밀번호" => "S3s@cSmtp!2024",
    "API Key (OpenAI)" => "sk-6tf8n6v...REDACTED",
    "API Key (Slack Bot)" => "xoxb-999999999-xxxxx-xxxxx",
    "JWT 시크릿 키" => "jwt_supersecret_sesac_2024!",
    "세션 타임아웃" => "30분",
    "파일 업로드 경로" => "/var/www/html/uploads",
    "최대 업로드 크기" => "20MB",
    "백업 주기" => "매일 오전 3시",
    "백업 파일 경로" => "/var/backups/system.tar.gz",
    "관리자 이메일" => "admin@admin.com",
    "로그 레벨" => "DEBUG",
    "CSRF Token Secret" => "csrf_sesac_key_@2024!",
    "S3 버킷 이름" => "sesac-prod-bucket",
    "ElasticSearch Endpoint" => "http://es.internal:9200",
    "환경 변수 (ENV)" => "PROD"
];

foreach ($settings as $key => $value) {
    echo "<tr><td><strong>$key</strong></td><td style='color: #C00000;'>$value</td></tr>";
}

echo "</table>";
?>
