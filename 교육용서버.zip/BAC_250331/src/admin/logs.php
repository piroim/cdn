<?php
$logs = [
    "[2025-03-30 08:15:12] [INFO] guest 로그인 성공",
    "[2025-03-30 08:16:42] [INFO] guest1 게시글 작성 완료",
    "[2025-03-30 08:17:05] [WARN] guest5 비정상 로그인 시도 (IP: 192.168.0.54)",
    "[2025-03-30 08:18:00] [INFO] admin 설정 페이지 접속",
    "[2025-03-30 08:19:11] [ERROR] DB 연결 지연 감지 (mysql.internal.local)",
    "[2025-03-30 08:20:09] [INFO] 백업 프로세스 시작",
    "[2025-03-30 08:21:32] [INFO] 백업 파일 생성 완료 (/var/backups/system.tar.gz)",
    "[2025-03-30 08:22:10] [INFO] guest2 비밀번호 변경 요청",
    "[2025-03-30 08:22:59] [INFO] Slack Webhook 전송 완료 (channel: #alerts)",
    "[2025-03-30 08:24:01] [WARN] CSRF 토큰 불일치 발생 (user: guest3)",
    "[2025-03-30 08:25:16] [INFO] 관리자 인증 토큰 갱신 완료",
    "[2025-03-30 08:26:45] [DEBUG] JWT Payload 검증 완료",
    "[2025-03-30 08:27:55] [INFO] 사용자 1245 탈퇴 요청 처리",
    "[2025-03-30 08:28:35] [ERROR] 업로드된 파일 크기 초과 (user: guest6)",
    "[2025-03-30 08:29:10] [INFO] 설정 변경 적용 (timezone => Asia/Seoul)",
    "[2025-03-30 08:30:22] [INFO] admin 로그인 성공",
    "[2025-03-30 08:31:55] [WARN] API Key 유효성 검사 실패",
    "[2025-03-30 08:33:01] [INFO] 서버 재시작 감지됨 (PID: 1203)",
    "[2025-03-30 08:35:17] [ERROR] 비정상 요청 감지 (method: DELETE, path: /admin/users)",
    "[2025-03-30 08:36:00] [INFO] 시스템 상태 점검 완료"
];

echo "<h1>📜 최근 시스템 로그</h1><pre style='background:#000;color:#0f0;padding:1em;border:1px solid #444;'>";

foreach ($logs as $log) {
    echo htmlspecialchars($log) . "\n";
}

echo "</pre>";
?>
