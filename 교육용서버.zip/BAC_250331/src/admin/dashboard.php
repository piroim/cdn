<?php
echo "<h1>📊 관리자 대시보드</h1>";
echo "<hr>";
echo "<h2>시스템 요약 정보</h2>";
echo "<ul>";
echo "<li>총 가입자 수: <strong style='color:green;'>2,439명</strong></li>";
echo "<li>오늘 로그인 사용자: <strong style='color:blue;'>152명</strong></li>";
echo "<li>현재 접속자 수: <strong style='color:orange;'>8명</strong></li>";
echo "<li>최근 가입자: <strong>guest2439 (2025-03-30)</strong></li>";
echo "<li>서버 상태: <strong style='color:green;'>정상</strong></li>";
echo "</ul>";

echo "<h2>관리 기능 단축 링크</h2>";
echo "<ul>";
echo "<li><a href='/users.php'>👥 사용자 관리</a></li>";
echo "<li><a href='/settings.php'>⚙️ 시스템 설정</a></li>";
echo "<li><a href='/logs.php'>📜 로그 보기</a></li>";
echo "</ul>";

echo "<hr>";
echo "<h2>보안 경고</h2>";
echo "<ul style='color: red;'>";
echo "<li>🔥 관리자 계정이 3일간 비밀번호를 변경하지 않았습니다.</li>";
echo "<li>⚠️ guest5 계정이 5회 이상 로그인 실패</li>";
echo "<li>⚠️ API 인증키 만료까지 5일 남음</li>";
echo "</ul>";

echo "<hr>";
echo "<h2>운영 알림</h2>";
echo "<pre style='background:#111;color:#0f0;padding:1em;border:1px solid #333;'>
[08:00] 백업 프로세스 완료 (/var/backups/system.tar.gz)
[08:30] 서버 상태 점검 완료 (CPU: 32%, RAM: 2.4GB/8GB)
[08:45] 신규 사용자 23명 등록
[09:00] 보안 점검 스케줄 등록 완료
</pre>";
?>
