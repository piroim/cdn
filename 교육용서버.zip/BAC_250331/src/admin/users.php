<?php
// users.php

$users = [
    ["guest", "guest", "guest@test.com"],
    ["guest1", "guest1", "guest1@test.com"],
    ["guest2", "guest2", "guest2@test.com"],
    ["guest3", "guest3", "guest3@test.com"],
    ["guest4", "guest4", "guest4@test.com"],
    ["guest5", "guest5", "guest5@test.com"],
    ["guest6", "guest6", "guest6@test.com"],
    ["guest7", "guest7", "guest7@test.com"],
    ["guest8", "guest8", "guest8@test.com"],
    ["guest9", "guest9", "guest9@test.com"],
    ["guest10", "guest10", "guest10@test.com"],
    ["guest11", "guest11", "guest11@test.com"],
    ["guest12", "guest12", "guest12@test.com"],
    ["guest13", "guest13", "guest13@test.com"],
    ["guest14", "guest14", "guest14@test.com"],
    ["guest15", "guest15", "guest15@test.com"],
    ["guest16", "guest16", "guest16@test.com"],
    ["guest17", "guest17", "guest17@test.com"],
    ["guest18", "guest18", "guest18@test.com"],
    ["guest19", "guest19", "guest19@test.com"],
    ["guest20", "guest20", "guest20@test.com"],
    ["guest21", "guest21", "guest21@test.com"],
    ["guest22", "guest22", "guest22@test.com"],
    ["guest23", "guest23", "guest23@test.com"],
    ["guest24", "guest24", "guest24@test.com"],
    ["guest25", "guest25", "guest25@test.com"],
    ["guest26", "guest26", "guest26@test.com"],
    ["guest27", "guest27", "guest27@test.com"],
    ["guest28", "guest28", "guest28@test.com"],
    ["guest29", "guest29", "guest29@test.com"],
    ["guest30", "guest30", "guest30@test.com"],
    ["admin", "security2025", "admin@admin.com"]
];

echo "<h1>🆙 전체 사용자 목록</h1>";
echo "<table border='1'><tr><th>이름</th><th>비밀번호</th><th>이메일</th></tr>";

foreach ($users as $user) {
    echo "<tr>";
    foreach ($user as $info) {
        echo "<td>" . htmlspecialchars($info) . "</td>";
    }
    echo "</tr>";
}

echo "</table>";
?>