<?php
    $db_conn = new mysqli("db", "root", "1324", "security");

    if($db_conn->connect_error) {
        die("MYSQL CONNECT FAIL :".$db_conn->connect_error);
    }
    $db_conn->set_charset("utf8mb4");
?>