<?php
    include 'common.php';  // 데이터베이스 연결 설정 포함
    include_once PUBLIC_PHP_PATH.'header.php';
    header("Access-Control-Allow-Origin: *");

    if(isset($_GET['keyword'])) {
        $a = htmlspecialchars($_GET['keyword']);
    } else {
        $a = "";
    }
?>

<html>
<body>
    <div class="search-container">
        <h2>[IDOR] 게시글 조회 2 - Patch V1.0</h2>
        <!-- <button type="button" class="button1"><a href='board_write.php'>게시글 작성</a></button><br> -->
        <form action="board2.php" method="get">
            <input type="text" class="search-box" name="keyword" placeholder="검색어를 입력하세요." value="<?php echo $a;?>"/>
            <button class="button" type="submit">검색</button>
            <button class="button" type="button" onclick="location.href='board2.php'">초기화</button>
        </form>
    </div>
    <table>
        <thead>
            <tr>
                <th>번호</th>
                <th class="subject">제목</th>
                <th class="writer">작성자</th>
                <th>작성일</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $current_page = isset($_GET['page']) ? $_GET['page'] : 1;
                $per_page = 7;
                $offset = ($current_page - 1) * $per_page;

                if(isset($_GET['keyword'])) {
                    $key = "%" . $_GET['keyword'] . "%";
                    $sql = $db_conn->prepare("SELECT COUNT(*) FROM board2 WHERE subject LIKE ?");
                    $sql->bind_param("s", $key);
                    $sql->execute();
                    $result = $sql->get_result();
                    $total_rows = $result->fetch_row()[0];
                    $total_pages = ceil($total_rows / $per_page);

                    $sql = $db_conn->prepare("SELECT * FROM board2 WHERE subject LIKE ? ORDER BY no DESC LIMIT ? OFFSET ?");
                    $sql->bind_param("sii", $key, $per_page, $offset);
                    $sql->execute();
                    $result = $sql->get_result();
                } else {
                    $sql = $db_conn->prepare("SELECT COUNT(*) FROM board2");
                    $sql->execute();
                    $result = $sql->get_result();
                    $total_rows = $result->fetch_row()[0];
                    $total_pages = ceil($total_rows / $per_page);

                    $sql = $db_conn->prepare("SELECT * FROM board2 ORDER BY no DESC LIMIT ? OFFSET ?");
                    $sql->bind_param("ii", $per_page, $offset);
                    $sql->execute();
                    $result = $sql->get_result();
                }

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>".$row["no"]."</td>";
                        echo "<td class='subject2'>";
                        if($row["writer"] === "admin") {
                            echo "<a href='board_detail2.php?no=".$row["no"]."' class='admin-post'>".$row["subject"]." [관리자]</a>";
                        } else {
                            echo "<a href='board_detail2.php?no=".$row["no"]."'>".$row["subject"]."</a>";
                        }
                        echo "</td>";
                        echo "<td>".$row["writer"]."</td>";
                        echo "<td>".$row["date"]."</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>게시글이 없습니다.</td></tr>";
                }
            ?>
        </tbody>
    </table>
    <div class="pagination">
        <?php
            if ($total_rows > 0) {
                for ($i = 1; $i <= $total_pages; $i++) {
                    echo "<a href='board2.php?page=$i&keyword=$a'". ($i == $current_page ? " class='current-page'" : "") .">$i</a> ";
                }
            }
        ?>
    </div>
</body>
</html>
<?php include_once PUBLIC_PHP_PATH.'footer.php'; ?>
