<?php
include 'common.php';  // 데이터베이스 연결 설정 포함

// 한글 처리를 위한 데이터베이스 문자셋 설정
$db_conn->set_charset("utf8mb4");

// 모든 게시글 삭제
$sql = "TRUNCATE TABLE board2;";

if ($db_conn->query($sql) === TRUE) {
    echo "모든 게시글이 성공적으로 삭제되었습니다.";
} else {
    echo "Error: " . $sql . "<br>" . $db_conn->error;
}

// 데이터베이스 연결 종료
$db_conn->close();
?> 