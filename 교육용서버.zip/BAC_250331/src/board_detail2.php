<?php
include 'common.php';
include_once PUBLIC_PHP_PATH.'header.php';

if(isset($_GET['no'])) {
    $no = htmlspecialchars($_GET['no']);
    $sql = $db_conn->prepare("SELECT * FROM board2 WHERE no = ?");
    $sql->bind_param("i", $no);
    $sql->execute();
    $result = $sql->get_result();

    if($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if ($row['writer'] == 'admin') {
            // 'admin'이 작성한 글일 경우
            echo "<script>
                    alert('관리자 외에는 접근할 수 없는 게시글입니다!');
                    window.location.href = 'board2.php';
                  </script>";
            exit(); // 스크립트 종료
        }
    } else {
        // 게시글이 없는 경우
        echo "<script>
                alert('존재하지 않는 게시글입니다.');
                window.location.href = 'board2.php';
              </script>";
        exit(); // 스크립트 종료
    }
}

/* 게시글 삭제 */
if(isset($_POST['delete']) && isset($_POST['no'])) {
    $no = $_POST['no'];
    $sql = $db_conn->prepare("DELETE FROM board2 WHERE no = ? AND writer != 'admin'");
    $sql->bind_param("i", $no);
    if ($sql->execute()) {
        header("Location: board2.php");
        exit();
    }
}
?>

<main>
    <div class="detail-container">
        <div class="title"><?php echo htmlspecialchars($row["subject"]); ?></div>
        <div class="content"><?php echo htmlspecialchars($row["content"]); ?></div>
        <div class="time"><?php echo "<div class='info'>" . htmlspecialchars($row["date"]) . " | 작성자 : " . htmlspecialchars($row["writer"]) . "</div>"; ?></div>
        
        <div class="button-group">
            <form id="deleteForm" action="board_detail.php" method="post">
                <input type="hidden" name="no" value="<?php echo $no; ?>">
                <!-- <input type="hidden" name="delete" value="1">
                <button type="button" onclick="confirmDelete()" class="button">삭제</button> -->
            </form>
            <a href="/board_edit.php?no=<?php echo $no; ?>" class="button">수정</a>
            <a href="/board2.php" class="button">목록</a>
        </div>
    </div>
</main>

<script>
    function confirmDelete() {
        if(confirm('정말로 삭제하시겠습니까?')) {
            document.getElementById('deleteForm').submit();
        }
    }
</script>

<?php include_once PUBLIC_PHP_PATH.'footer.php'; ?>
