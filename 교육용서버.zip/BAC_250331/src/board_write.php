<?php    
    include 'common.php'; 
    include PUBLIC_PHP_PATH.'header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/public/css/style.css">
    <title>게시글 작성</title>
</head>
<body>
    <div class="search-container">
        <h2>게시글 작성</h2>
    </div>
    <div class="detail-container">
        <form action="write_post.php" method="post">
            <label for="subject">제목:</label>
            <input type="text" name="subject" id="subject" required><br><br>

            <label for="content">내용:</label><br>
            <textarea name="content" id="content" rows="4" cols="50" required></textarea><br><br>

            <input type="submit" value="게시글 작성">
        </form>
    </div>
</body>
</html>
<?php include PUBLIC_PHP_PATH.'footer.php'; ?>