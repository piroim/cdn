<?php
include 'common.php';

include_once PUBLIC_PHP_PATH.'header.php';

/*DB에서 게시글 정보 가져오기*/
if(isset($_GET['no'])) {
    $no = htmlspecialchars($_GET['no']);
    $sql = $db_conn->prepare("SELECT * FROM board WHERE no = ?");
    $sql->bind_param("i", $no);
    $sql->execute();
    $result = $sql->get_result();

    if($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    }
    else {
        // 게시글이 없는 경우
        echo "<script>
                alert('존재하지 않는 게시글입니다.');
                window.location.href = 'board.php';
              </script>";
        exit(); // 스크립트 종료
    }
}
/*게시글 삭제 */
if(isset($_POST['delete']) && isset($_POST['no'])) {
    $no = $_POST['no'];
    $sql = $db_conn->prepare("DELETE FROM board WHERE no = ?");
    $sql->bind_param("i", $no);
    $sql->execute();
    header("Location: board.php");
    exit();
}
?>
<main>
    <div class="detail-container">
    <div class="title"><?php echo $row["subject"]; ?></div>
    <div class="content"><?php echo $row["content"]; ?></div>
    <div class="time"><?php echo "<div class='info'>" . $row["date"] . " | 작성자 : " . $row["writer"] . "</div>"; ?></div>
    
    <div class="button-group">

    <form id="deleteForm" action="board_detail.php" method="post">
        <input type="hidden" name="no" value="<?php echo $no; ?>">
        <input type="hidden" name="delete" value="1">
    </form>

    <!-- <a href="javascript:void(0);" onclick="confirmDelete()" class="button">삭제</a> -->
    <a href="/board.php" class="button">목록</a>

    </div>
    </div>
</main>

<script>
    function confirmDelete() {
        if(confirm('정말로 삭제하시겠습니까?')) {
            document.getElementById('deleteForm').submit();
        }
    }
</script>

<?php  include_once PUBLIC_PHP_PATH.'footer.php'; ?>