<?php
    include 'common.php';
    include PUBLIC_PHP_PATH.'header.php';
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>메인 페이지</title>
</head>
<body>
    <h1 style="text-align=center">🏠 메인 페이지</h1>
    <p>이곳은 공개 영역입니다. 로그인 없이 접근 가능합니다.</p>
    <p>게시판, 공지사항, 고객센터 등의 링크가 여기에 올 수 있습니다.</p>

    <div id="posts">
        <p>게시글을 불러오는 중입니다...</p>
    </div>

    <script src="/public/js/main.js"></script>
    <script src="/public/js/admin.js"></script>
</body>
</html>
<?php include_once PUBLIC_PHP_PATH.'footer.php'; ?>