CREATE TABLE security_user(
    no int not null auto_increment,
    name VARCHAR(30) NOT NUll,
    password VARCHAR(30) NOT NUll,
    email VARCHAR(50) NOT NUll,
    PRIMARY KEY(no)
);

INSERT INTO security_user(name, password, email) VALUES
    ("guest", "guest", "guest@test.com"),
    ("guest1", "guest1", "guest1@test.com"),
    ("guest2", "guest2", "guest2@test.com"),
    ("guest3", "guest3", "guest3@test.com"),
    ("guest4", "guest4", "guest4@test.com"),
    ("guest5", "guest5", "guest5@test.com"),
    ("guest6", "guest6", "guest6@test.com"),
    ("guest7", "guest7", "guest7@test.com"),
    ("guest8", "guest8", "guest8@test.com"),
    ("guest9", "guest9", "guest9@test.com"),
    ("guest10", "guest10", "guest10@test.com"),
    ("guest11", "guest11", "guest11@test.com"),
    ("guest12", "guest12", "guest12@test.com"),
    ("guest13", "guest13", "guest13@test.com"),
    ("guest14", "guest14", "guest14@test.com"),
    ("guest15", "guest15", "guest15@test.com"),
    ("guest16", "guest16", "guest16@test.com"),
    ("guest17", "guest17", "guest17@test.com"),
    ("guest18", "guest18", "guest18@test.com"),
    ("guest19", "guest19", "guest19@test.com"),
    ("guest20", "guest20", "guest20@test.com"),
    ("guest21", "guest21", "guest21@test.com"),
    ("guest22", "guest22", "guest22@test.com"),
    ("guest23", "guest23", "guest23@test.com"),
    ("guest24", "guest24", "guest24@test.com"),
    ("guest25", "guest25", "guest25@test.com"),
    ("guest26", "guest26", "guest26@test.com"),
    ("guest27", "guest27", "guest27@test.com"),
    ("guest28", "guest28", "guest28@test.com"),
    ("guest29", "guest29", "guest29@test.com"),
    ("guest30", "guest30", "guest30@test.com"),
    ("admin", "security2025", "admin@admin.com");

CREATE TABLE board(
    no int not null auto_increment,
    subject VARCHAR(30) NOT NULl,
    writer VARCHAR(30),
    content VARCHAR(1000) NOT NULL,
    date DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY(no)
);

CREATE TABLE board2(
    no int not null auto_increment,
    subject VARCHAR(30) NOT NULl,
    writer VARCHAR(30),
    content VARCHAR(1000) NOT NULL,
    date DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY(no)
);

CREATE TABLE board3(
    no int not null auto_increment,
    subject VARCHAR(30) NOT NULl,
    writer VARCHAR(30),
    content VARCHAR(1000) NOT NULL,
    date DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY(no)
);

ALTER DATABASE security CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci;
ALTER TABLE board CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE board2 CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE board3 CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

INSERT INTO board(subject, writer, content) VALUES
    ("Fake","guest","SeSAC{Fake_Flag}");

INSERT INTO board2(subject, writer, content) VALUES
    ("Fake","guest","SeSAC{Fake_Flag}");

INSERT INTO board3(subject, writer, content) VALUES
    ("Fake","guest","SeSAC{Fake_Flag}");