#!/bin/bash
apache2-foreground &  # Apache 서버 백그라운드 실행
chmod +x /bot.py
python3 /bot.py  # bot.py 실행