CREATE TABLE security_user(
    no int not null auto_increment,
    name VARCHAR(30) NOT NUll,
    password VARCHAR(30) NOT NUll,
    PRIMARY KEY(no)
);

INSERT INTO security_user(name, password) VALUES
    ("guest", "guest"),
    ("guest1", "guest1"),
    ("guest2", "guest2"),
    ("guest3", "guest3"),
    ("guest4", "guest4"),
    ("guest5", "guest5"),
    ("guest6", "guest6"),
    ("guest7", "guest7"),
    ("guest8", "guest8"),
    ("guest9", "guest9"),
    ("guest10", "guest10"),
    ("guest11", "guest11"),
    ("guest12", "guest12"),
    ("guest13", "guest13"),
    ("guest14", "guest14"),
    ("guest15", "guest15"),
    ("guest16", "guest16"),
    ("guest17", "guest17"),
    ("guest18", "guest18"),
    ("guest19", "guest19"),
    ("guest20", "guest20"),
    ("admin", "admin");
