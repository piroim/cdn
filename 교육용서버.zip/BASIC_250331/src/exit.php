<?php
session_name('HIJACKING'); // 세션 이름을 'HIJACKING'으로 설정
session_start();

include 'common.php';
include_once PUBLIC_PHP_PATH.'header.php';

// 관리자 쿠키 값
$adminCookieValue = 12333;
$startCookieValue = 12300;
$endCookieValue = 12400;

// 쿠키 'HIJACKING' 값을 설정하거나 업데이트
if (isset($_COOKIE['HIJACKING'])) {
    $currentValue = intval($_COOKIE['HIJACKING']);
    // 관리자 값인 12333을 제외하고 증가
    if ($currentValue == $adminCookieValue) {
        // 관리자 값이면 증가하지 않고 유지
    } 
    else {
        $currentValue++;
        if ($currentValue > $endCookieValue) {
            $currentValue = $startCookieValue; // 최대값 초과 시 초기값으로 리셋
        }
    }
} else {
    $currentValue = $startCookieValue;
}

// 쿠키를 설정
setcookie('HIJACKING', $currentValue, time() + 3600, '/'); // 쿠키 1시간 동안 유효

// 로그아웃 처리
if (isset($_GET['logout'])) {
    setcookie('HIJACKING', '', time() - 3600, '/'); // 쿠키 삭제
    session_destroy();
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// 세션 값을 확인하고 권한을 결정
if ($currentValue == $adminCookieValue) {
    $role = 'admin';
} else {
    $role = 'none'; // 사용자가 없음
}
?>

<html>
<head><style></style></head>
<body>
    <div class="search-container">
        <h2>[Session Hijacking] 세션을 이용한 이용자 로그인</h2>
        <h3>세션 값을 확인해 로그인한 이용자 상태정보 출력</h3>
        <p>관리자로 로그인하여 FLAG를 획득하세요.</p>
        <p>이용자는 100명이 존재합니다.</p>
        <a href="?logout=true">세션 값 초기화</a>
    </div>
    <?php
    if ($role == 'admin') {
        echo "<script>alert('세션탈취 성공!')</script>";
        echo "<h3 align=center style='color: #501A9B;'>관리자 계정입니다. SA2024{Session_Hijacking_Clear}</h3>";
    } else {
        echo "<h3 align=center style='color: #0070C0;'>해당 이용자는 로그인하지 않았습니다.</h3>";
    }
    ?>
    <br>
    <div class="info-container">
        <!-- 정보 출력 공간 -->
    </div>

</body>
</html>

<?php include_once PUBLIC_PHP_PATH.'footer.php'; ?>