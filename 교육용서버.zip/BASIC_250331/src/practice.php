<?php
    include 'common.php';
    include_once PUBLIC_PHP_PATH.'header.php';

    // 세션 시작
    session_start();

    //Error 출력코드
    ini_set('display_errors', 1);
    mysqli_report(MYSQLI_REPORT_ERROR);
    // $query = isset($_GET['query']) ? $_GET['query'] : '' ;

    // 쿠키로부터 세션 값 설정
    if (isset($_COOKIE['Session'])) {
        $role = $_COOKIE['Session'];
        // 계정 이름 확인 및 세션 할당
        if ($role == 'admin' || $role == 'guest' || $role == 'guest1' || $role == 'guest2') {
            $_SESSION['role'] = $role;
        } else {
            $_SESSION['role'] = 'none'; // 알려지지 않은 계정
        }
    } else {
        $_SESSION['role'] = 'none'; // 쿠키가 없을 때 기본 값 설정
    }
?>

<html>
    <head><style></style></head>
    <body>
        <div class="search-container">
        <h2>[Cookie] 사용자 로그인 테스트<h2>
            <p>쿠키 값을 입력해주세요.</p>
            <p>Name=Session, Value={계정명}</p>
        </div>

        <?php
            switch ($_SESSION['role']) {
                case 'admin':
                    echo "<h3 align=center style='color: #501A9B;'>관리자(admin)로 로그인하셨습니다.</h3>";
                    break;
                case 'guest':
                case 'guest1':
                case 'guest2':
                    echo "<h3 align=center style='color: #0070C0;'>게스트($_SESSION[role])로 로그인하셨습니다.</h3>";
                    break;
                default:
                    echo '<p align=center>로그인 상태가 아닙니다.</p>';
                    break;
            }
        ?> 
        <br>
        <div class="search-container">
            <h2>기본계정 목록</h2>
            <p>guest, guest1, guest2, admin</p>
        </div>

    </body>
</html>

<?php include_once PUBLIC_PHP_PATH.'footer.php'; ?>
