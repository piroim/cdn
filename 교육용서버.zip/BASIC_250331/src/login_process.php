<?php
    include 'common.php';
    

    if(!session_id()) {
        session_name('SESSIONTEST');
        session_start();
    }

    if($_SERVER['REQUEST_METHOD'] === 'POST') {
        $id = $_POST['username'];
        $pw = $_POST['password'];
        $sql = $db_conn->prepare("SELECT * FROM security_user WHERE name=? and password=?");
        $sql->bind_param("ss",$id, $pw);
        if($sql->execute()) {
            $sql->store_result();
            $num_rows = $sql->num_rows;
            if($num_rows > 0) {
                $_SESSION['username'] = $id;
                $_SESSION['start_time'] = time();
                $_SESSION['expire_time'] = 5 * 60;
                echo "<script>alert('로그인 성공')</script>";
                echo "<script>window.location.href = 'index.php';</script>";
                exit();
            }
            else {
                echo "<script>alert('입력 값이 잘 못 됨');</script>";
                echo "<script>window.location.href = 'login.php';</script>";
                exit();
            }
        };
    };
?>