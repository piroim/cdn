<?php
session_name('SESSIONTEST');
session_start();

include 'common.php';
include_once PUBLIC_PHP_PATH.'header.php';

// 데이터베이스 연결
$host = 'localhost'; // 데이터베이스 서버 주소
$dbUsername = 'root'; // 데이터베이스 사용자 이름
$dbPassword = ''; // 데이터베이스 비밀번호
$dbName = 'testdb'; // 데이터베이스 이름

$conn = new mysqli($host, $dbUsername, $dbPassword, $dbName);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// 로그인 처리
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $conn->real_escape_string($_POST['username']);
    
    $query = "SELECT * FROM users WHERE username = '$username'";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $_SESSION['user'] = $username; // 사용자 이름으로 세션 설정
    } else {
        $_SESSION['user'] = 'none'; // 사용자가 없는 경우
    }
}

// 로그아웃 처리
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

?>

<html>
<head><style></style></head>
<body>
    <div class="search-container">
        <h2>[Session] 사용자 로그인 테스트</h2>
        <form action="" method="post">
            <input type="text" class="search-box" name="username" placeholder="계정을 입력하세요(admin, guest)" autofocus>
            <button class="button" type="submit">로그인</button>
        </form>
        <a href="?logout=true">로그아웃</a>
    </div>
    <?php
    if (isset($_SESSION['user']) && $_SESSION['user'] != 'none') {
        echo '<p>현재 로그인된 사용자: ' . htmlspecialchars($_SESSION['user']) . '</p>';
    } else {
        echo '<p align=center>로그인 상태가 아닙니다.</p>';
    }
    ?>
    <br>
    <div class="info-container">
        <!-- 정보 출력 공간 -->
    </div>

</body>
</html>

<?php 
$conn->close();
include_once PUBLIC_PHP_PATH.'footer.php'; 
?>
