<?php
include 'common.php';
include_once PUBLIC_PHP_PATH.'header.php';

// 로그인 처리
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $db_conn->real_escape_string($_POST['username']);
    
    $query = "SELECT name FROM security_user WHERE name = '$username'";
    $result = $db_conn->query($query);

    if ($result->num_rows > 0) {
        $_SESSION['username'] = $username; // 사용자 이름으로 세션 설정
    } else {
        $_SESSION['username'] = 'none'; // 사용자가 없는 경우
    }
}

?>

<html>
<head><style></style></head>
<body>
    <div class="search-container">
        <h2>[Session] 사용자 로그인 테스트<h2>
        <form action="" method="post">
            <input type="text" class="search-box" name="username" placeholder="계정을 입력하세요(admin, guest)" autofocus>
            <button class="button" type="submit">로그인</button>
        </form>
        <a href="logout.php">로그아웃(세션제거)</a>
    </div>
    <?php
        if (isset($_SESSION['username']) && $_SESSION['username'] == 'admin') {
            echo "<h3 align=center style='color: #501A9B;'>관리자(admin)로 로그인하셨습니다.</h3>";
            echo '<h3 align=center style="color: #501A9B;"><p>세션정보 : ' . session_id() . '</p></h3>';

        } 
        else {
            if(empty($_SESSION['username']) || $_SESSION['username'] == 'none') {
                echo '<h3 align=center style="color: #000000;"><p>현재 로그인된 사용자: ' . htmlspecialchars($_SESSION['username']) . '</p></h3>';
                echo '<h3 align=center style="color: #000000;"><p>세션정보 : ' . session_id() . '</p></h3>';
            }
            else{
                echo '<h3 align=center style="color: #0070C0;"><p>현재 로그인된 사용자: ' . htmlspecialchars($_SESSION['username']) . '</p></h3>';
                echo '<h3 align=center style="color: #0070C0;"><p>세션정보 : ' . session_id() . '</p></h3>';
            }
        }
    ?>
    <br>

</body>
</html>

<?php include_once PUBLIC_PHP_PATH.'footer.php'; ?>
