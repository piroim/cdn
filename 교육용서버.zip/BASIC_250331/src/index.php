<?php
    include 'common.php';
    include PUBLIC_PHP_PATH.'header.php';
?>
<html>
    <body>
        <br>
        <h2>Penetration Testing</h2>
        <p>실습페이지 입니다.</p>
        <!-- <button id="myButton" disabled>Hidden Button</button> -->

        <!-- <script>
            document.getElementById("myButton").addEventListener("click", function() {
                alert("SA2024{버튼이 활성화되었습니다!}");
            });

            function enableButton() {
                document.getElementById("myButton").disabled = false;
            }
        </script> -->
    </body>
</html>

<?php include_once PUBLIC_PHP_PATH.'footer.php'; ?>