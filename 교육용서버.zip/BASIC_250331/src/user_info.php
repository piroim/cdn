<?php
    include 'common.php';
    include_once PUBLIC_PHP_PATH.'header.php';
?>

<main>
    <h2>회원정보</h2>
    
    <?php 
        if (isset($_SESSION['start_time'])) {
            $elapsed_time = time() - $_SESSION['start_time'];
            $remaining_time = $_SESSION['expire_time'] - $elapsed_time;
            
            if ($remaining_time > 0) {
                echo "<div id='session_timer'>세션시간 : <span id='timer'>" . $remaining_time . "</span></div>";
                $session_time = $remaining_time;
                
                echo "<script>var remainingTime = $remaining_time;</script>";
            } else {
                echo "<script>alert('로그인 필요')</script>";
                session_destroy();
            }
        } else {
            echo "로그인 필요";
        }

        if (isset($_SESSION['username'])) {
            $username = $_SESSION['username'];
            echo $username;
        }
        //flag
        // if (isset($_SESSION['username'])) {
        //     $username = $_SESSION['username'];
            
        //     if($username === "admin")
        //         echo $flag;
        //     else
        //         echo "XSS{...}";
        // }
    ?>
</main>

<?php include_once PUBLIC_PHP_PATH.'footer.php'; ?>

<script>
    function updateTimer() {
        if (remainingTime > 0) {
            remainingTime--;
            var minutes = Math.floor(remainingTime / 60);
            var seconds = remainingTime % 60;
            document.getElementById('timer').textContent = minutes + "분 " + seconds + "초";
        } else {
            clearInterval(timerInterval);
            document.getElementById('session_timer').textContent = "세션 만료";
            // 필요한 경우 추가 액션 수행
        }
    }

    // 1초마다 타이머 업데이트
    var timerInterval = setInterval(updateTimer, 1000);
    var sessionId = "<?php echo session_id(); ?>";
</script>