<?php
    include 'common.php';
    include PUBLIC_PHP_PATH.'header.php';
?>
<html>
    <body>
        <br>
        <h2>Penetration Testing</h2>
        <p>실습페이지 입니다.</p>
    </body>
</html>

<?php include_once PUBLIC_PHP_PATH.'footer.php'; ?>