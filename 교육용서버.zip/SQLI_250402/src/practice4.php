<?php
    include 'common.php';
    include_once PUBLIC_PHP_PATH.'header.php';
    //Error 출력코드
    ini_set('display_errors', 1);
    mysqli_report(MYSQLI_REPORT_ERROR);
    $query = isset($_GET['query']) ? $_GET['query'] : '' ;
?>

<html>
    <head><style></style></head>
    <body>
        <div class="search-container">
        <h2>[Error Based Injection] 사용자 정보 검색기능<h2>
            <form action="" method="get">
                <input type="text" class="search-box" id="query" name="query" placeholder="쿼리를 입력하세요." autofocus value="<?php echo htmlspecialchars($query); ?>">
                <button class="button" type="submit">검색</button>
            </form>
        </div>

        <?php
            if (!empty($query)) {
                echo "<div class='search-container'><hr><span>mysql[security]> <strong>SELECT * FROM {table} WHERE {column} = '<span class='query-highlight'>".htmlspecialchars($query)."</span>'</strong></span></div>";

                $sql = $db_conn->prepare("SELECT * FROM security_user WHERE name='$query'");
                if(!$sql->execute()) {
                    echo $db_conn->errno;
                }
                else {
                    $result = $sql->get_result();
                }
                
                echo "<table border='1'>";
                echo "<tr>";

                $fields = $result->fetch_fields();
                foreach ($fields as $fieldinfo) {
                    echo "<th>" . htmlspecialchars($fieldinfo->name) . "</th>";
                }
                echo "</tr>";
        
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        foreach ($row as $data) {
                            echo "<td>" . htmlspecialchars($data) . "</td>";
                        }
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='".count($fields)."'>검색 결과가 없습니다.</td></tr>";
                }
                echo "</table>";
                $sql->close();
            } else {
                echo "<p align='center'>쿼리를 입력해주세요</p>";
            }
        ?> 
        <br>
        <div class="search-container">
            <h2>Source Code</h2>
            <?php
                $code = '<?php echo $query = isset($_GET["query"]) ? $_GET["query"] : ""; ' ."\n".
                '$sql = $db_conn->prepare("SELECT * FROM {table} WHERE {column} =\'$query\'");';
                highlight_string($code);
            ?>
        </div>

    </body>
</html>
<?php include_once PUBLIC_PHP_PATH.'footer.php'; ?>


