<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Security Academy - piro_im</title>
        <link rel="stylesheet" href="/public/css/style.css">
        <link rel="stylesheet" href="/public/css/board.css">
    </head>
    <body>
        <header>
            <a href="/index.php" style="text-decoration: none;"><h1>[실습] SQL INJECTION</h1></a>
        </header>
        <nav>
            <ul>
                <li><a href="/">메인</a></li>
                <li><a href="practice.php">실습</a></li>
                <li><a href="practice1.php">실습2</a></li>
                <li><a href="practice2.php">실습3</a></li>
                <li><a href="practice3.php">실습4</a></li>
                <li><a href="practice4.php">실습5</a></li>
                <li><a href="level0.php">level0</a></li>
                <li><a href="level1.php">level1</a></li>
                <li><a href="level2.php">level2</a></li>
            </ul>
        </nav>
    </body>
</html>