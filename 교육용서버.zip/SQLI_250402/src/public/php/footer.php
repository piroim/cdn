<footer>
    <p>&copy; 2024 Security Academy - piro_im</p>
</footer>