<?php
    include 'common.php';
    include_once PUBLIC_PHP_PATH.'header.php';

    if(!isset($_SESSION['username'])) {
        // echo "로그인 안되어있음";            
    }
    else {
        echo "<script>location.replace('user_info.php');</script>"; 
    }
?>
<html>
    <head>
        <link rel="stylesheet" href="/public/css/login.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
    </head>
    <style>

    </style>
    <body>
        <form action="login_process.php" method="POST">
            <div class="login-form-box">
                <h2>로그인</h2>
                <div class="input-with-icon">
                    <i class="fa fa-user"></i>
                    <input type="text" id="username" name="username" placeholder="ID" required>
                </div>

                <div class="input-with-icon">
                    <i class="fa fa-lock"></i>
                    <input type="password" id="password" name="password" placeholder="PW" required>
                </div>
                <div class="button-container">
                    <input type="submit" value="로그인" class="button">
                    <input type="button" value="회원가입" class="button" onclick="location.href='login_register.php'">
                </div>

                <div class="additional-links">
                    <a href="#" onclick="openFindIdPopup(); return false;" style="text-decoration: none; color: inherit;">아이디 찾기</a> |
                    <a href="#" class="link">비밀번호 찾기</a> |
                    <a href="#" class="link">이메일 문의</a>
                </div>
            </div>
        </form>
        
    <script>
        function openFindIdPopup() {
            // 팝업 창의 크기 설정
            var popupWidth = 600;
            var popupHeight = 400;

            // 화면의 중앙 위치를 계산
            var windowWidth = window.screen.width;
            var windowHeight = window.screen.height;
            var popupLeft = (windowWidth - popupWidth) / 2;
            var popupTop = (windowHeight - popupHeight) / 2;

            // 팝업 창 열기
            var popupWindow = window.open(
                "find_id.php",
                "Find ID",
                "width=" + popupWidth + ",height=" + popupHeight + ",left=" + popupLeft + ",top=" + popupTop
            );
        }

    </script>
    </body>
</html>

<?php include_once PUBLIC_PHP_PATH.'footer.php'; ?>

