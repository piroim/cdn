<?php
    include 'common.php';
    include_once PUBLIC_PHP_PATH.'header.php';
    //Error 출력코드
    ini_set('display_errors', 1);
    mysqli_report(MYSQLI_REPORT_ERROR);
    $id = isset($_GET['id']) ? filter($_GET['id']) : '' ;
    $pw = isset($_GET['pw']) ? filter($_GET['pw']) : '' ;

    function filter($id) {
        $id = preg_replace('/admin/i', '_', $id);
        return $id;
    }
?>

<html>
    <head>
        <link rel="stylesheet" href="/public/css/login.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
    </head>
    <body>
        <div class="search-container">
            <h2>로그인 정보를 입력해주세요. (Patch V1.1)<h2>
        </div>
        <?php
            
            echo "<div class='search-container'><span>mysql[]> <strong>SELECT * FROM level1 WHERE id = '<span class='query-highlight'>".htmlspecialchars($id)."</span>' and pw = '<span class='query-highlight'>".htmlspecialchars($pw)."</span>';</strong></span></div>";

            $sql = $db_conn->prepare("SELECT * FROM level1 WHERE id='$id' and pass='$pw'");
            if(!$sql->execute()) {
                echo $db_conn->errno;
            }
            else {
                $result = $sql->get_result();
                if($result->num_rows > 0) {
                    $user = $result->fetch_assoc();
                    
                    if($user['id'] == 'admin') {
                        echo "<script>alert('Level1 Clear ! FLAG IS \"SA2024{SQLI_Level2_Clear}\"')</script>";
                        echo "<br><h3 align='center' style='color: #C00000;'>SA2024{SQLI_Level2_Clear}</h3>";
                    } else {
                        echo "<br><h3 align='center' style='color: #0070C0;'>Not ADMIN, No FLAG</h3>";
                    }
                } 
            }
            
            $sql->close();
            
        ?>
        <div class="center-container">
        <div class="login-form-box">
            <form action="" method="get">
                <h2>로그인</h2>
                <div class="input-with-icon">
                    <i class="fa fa-user"></i>
                    <input type="text" id="id" name="id" placeholder="ID를 입력하세요." required>
                </div>

                <div class="input-with-icon">
                    <i class="fa fa-lock"></i>
                    <input type="password" id="pw" name="pw" placeholder="PW를 입력하세요." required>
                </div>
                <div class="button-container">
                    <input type="submit" value="로그인" class="button">
                    <input type="button" value="회원가입" class="button">
                </div>
            </form>
        </div>
        </div>
    </body>
</html>
<?php include_once PUBLIC_PHP_PATH.'footer.php'; ?>


