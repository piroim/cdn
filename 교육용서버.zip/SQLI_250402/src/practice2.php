<?php
    include 'common.php';
    include_once PUBLIC_PHP_PATH.'header.php';
    //Error 출력코드
    ini_set('display_errors', 1);
    mysqli_report(MYSQLI_REPORT_ERROR);
    $query = isset($_GET['query']) ? $_GET['query'] : '' ;
?>

<html>
    <head><style></style></head>
    <body>
        <div class="search-container">
        <h2>[Boolean Based Injection] 사용자 정보 검색기능<h2>
            <form action="" method="get">
                <input type="text" class="search-box" id="query" name="query" placeholder="쿼리를 입력하세요." autofocus value="<?php echo htmlspecialchars($query); ?>">
                <button class="button" type="submit">검색</button>
            </form>
        </div>

        <?php
            if (!empty($query)) {
                echo "<div class='search-container'><hr><span>mysql[null]> <strong>SELECT * FROM {table} WHERE {column} = '<span class='query-highlight'>".htmlspecialchars($query)."</span>'</strong></span></div>";

                $sql = $db_conn->prepare("SELECT * FROM level1 WHERE id='$query'");
                if(!$sql->execute()) {
                    echo $db_conn->errno;
                }
                else {
                    $result = $sql->get_result();
                }
        
                if ($result->num_rows > 0) {
                    echo "<br><p style='color: #C00000; font-weight: bold; text-align: center;'>계정이 있습니다.</p>";
                } else {
                    echo "<br><p style='color: #000; font-weight: bold; text-align: center;'>계정이 없습니다.</p>";
                }
                $sql->close();
            } else {
                echo "<p align='center'>쿼리를 입력해주세요</p>";
            }
        ?> 
        <br>
        <div class="search-container">
            <h2>Source Code</h2>
            <?php
                $code = '<?php echo $query = isset($_GET["query"]) ? $_GET["query"] : ""; ' ."\n".
                '$sql = $db_conn->query("SELECT * FROM {table} WHERE {column} =\'$query\'");';
                highlight_string($code);
            ?>
        </div>


    </body>
</html>
<?php include_once PUBLIC_PHP_PATH.'footer.php'; ?>


